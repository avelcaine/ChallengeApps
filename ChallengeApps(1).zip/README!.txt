============================         
          Project "ChallengeApp"
============================
-----------------------------------
Detail on Files Inside  //
-----------------------------------
1. ChallengeApps Folder (Android Studio Project Files)
    - File utama proyek android yang dibuat. 
    - Atur koneksi ke database local lewat "C:\Users\avelc\Documents\Big Task\ChallengeApps\app\src\main\java\com\avelcaine\challengeapps\app\AppConfig.java"

2. localhost Folder (API of Database, and Dump Files of DB used)
    - didalam "/localhost" ada dua item, folder dan satunya lagi file dengan format ".sql"
    - letakkan folder "android_login_api" di localhost yang anda punya (saya pakai wamp, jadi lokasinya "wamp/www/)
    - file "databases.sql" adalah file dump dari database yang saya punya, cukup import saja, database dan table akan masuk semua
-----------------------------------------
If there are Problems...     //
----------------------------------------
1. Beritahu lewat WhatsApp, Chat via Facebook (a.n. Dzul Kahfi), atau Direct di Discord (@avelcaine#7546)
2. Email (not recommended, jika yang lain tidak bisa saja)

Sudah saya cek, dan tidak ada masalah terkait file-nya.
Semoga saja bisa selamat sampai tujuan.
-------------------------------
End of Words         //
-------------------------------
Nama: Dzulkahfi
NIM: D1042151048

mohon maaf untuk segala ketidaknyamanannya, semoga diterima dengan baik dan dapat dijalankan
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------