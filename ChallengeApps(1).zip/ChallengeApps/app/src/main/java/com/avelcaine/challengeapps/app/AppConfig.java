package com.avelcaine.challengeapps.app;

public class AppConfig {
    // Server user login url
    public static String URL_LOGIN = "https://437786be.ngrok.io/android_login_api/login.php";

    // Server user register url
    public static String URL_REGISTER = "https://437786be.ngrok.io/android_login_api/register.php";
}